MOTOGP 26 / PS5 — 100-IMAGE GAME-DEVELOPMENT REFERENCE PACK
================================================================

Exactly 100 numbered JPEG references, a source manifest, contact sheets and this guide.

SOURCE POLICY
- No broad search-result fallback is included.
- All 100 items were visually reviewed as MotoGP 26 game imagery or curated detail crops derived from it.
- Folder 01 contains direct official PlayStation Store PS5 captures.
- Folder 05 contains four 1920x1080 modeling-detail crops derived from those official PS5 captures.
- Other folders contain verified MotoGP 26 promotional screenshots or frames from official Steam-hosted game trailers; those sources do not always identify the capture platform as PS5.

FOLDER BREAKDOWN
- 01_official_ps5_store: 10 images
- 02_ui_menus_hud: 3 images
- 03_gameplay_models_tracks: 34 images
- 04_official_trailer_frames: 49 images
- 05_official_ps5_detail_crops: 4 images

DEVELOPER USE
- 3D motorcycles: silhouette, fairing seams, aero surfaces, suspension, brakes, wheels, tires, cockpit, materials and livery placement.
- Riders: suit, helmet, gloves and boots; lean posture; knee/elbow contact; weight transfer and off-road body positioning.
- Tracks: asphalt, curbs, barriers, fencing, pits, grandstands, vegetation, weather, dirt surfaces and scale cues.
- Gameplay: chase/onboard/replay cameras, braking pitch, corner entry, racing lines, pack spacing, wet feedback and mixed-bike disciplines.
- UI/UX: hierarchy, typography, telemetry, setup flow, rider identity, focus states, safe areas and split-screen density.
- Rendering/VFX: reflections, wet materials, spray, motion blur, depth of field, particles, lighting, shadows and broadcast framing.

RIGHTS NOTICE
For internal visual research and developer reference only. This pack does not transfer copyright, trademark, sponsor-livery, rider-likeness or redistribution rights.
Do not ship, publish, resell or redistribute the source images without permission. Re-create principles rather than copying protected logos, liveries or branded UI one-to-one.
Every item is traceable in MANIFEST.csv.

QUALITY CONTROL
- Exactly 100 numbered reference images.
- All five category contact sheets were visually reviewed.
- Four low-value transition/title frames were replaced with model-focused PS5 detail crops.
- Blank, low-resolution, heavily letterboxed and near-duplicate candidates were rejected.
- Dimensions and SHA-256 hashes are recorded in MANIFEST.csv.
